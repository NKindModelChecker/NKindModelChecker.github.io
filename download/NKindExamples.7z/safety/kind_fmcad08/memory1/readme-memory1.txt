Sources for benchmarks

DRAGON*, FIREFLY*: Based on problems by David Merchat 
  (courtesy of Anders Franzen)


Please note that many of these benchmarks contain deliberately introduced
modifications to alter their behaviors, and do not necessarily reflect the
original creator's design intentions.
